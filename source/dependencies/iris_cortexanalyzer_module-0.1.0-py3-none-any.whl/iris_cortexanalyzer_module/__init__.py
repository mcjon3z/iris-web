#!/usr/bin/env python3
#
#
#  IRIS cortexanalyzer Source Code
#  Copyright (C) 2023 - SOCFortress
#  info@socfortress.co
#  Created by SOCFortress - 2023-03-06
#
#  License MIT

__iris_module_interface = "IrisCortexanalyzerInterface"